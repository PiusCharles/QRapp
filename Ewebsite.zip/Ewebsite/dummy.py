import random
import qrcode
x = random.randint(100000,999999)
print(x)
img = qrcode.make("OTP is"+str(x))
img.save("file1.png")
