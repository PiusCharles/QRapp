import random

import qrcode
from django.shortcuts import render
otp = 0
def openLoginPage(request):
    return render(request,"login.html")

def validateuser(request):
    username = request.POST.get("t1")
    password = request.POST.get("t2")

    if username == "naveen" and password == "Kumar":
        rno = random.randint(100000,999999)
        global otp
        otp = rno
        im = qrcode.make("OTP :"+str(rno))
        im.save(r"static/qrimages/naveen.jpg")
        return render(request,"qrcode_page.html")
    else:
        return render(request,"login.html", {"message":"Invalid User"})

def validateOTP(request):
    user_otp = request.POST.get("otp")
    if user_otp == str(otp):
        return render(request,"welcome.html")
    else:
        return render(request,"login.html", {"message":"Invalid User"})
